# CodeKids Adventure 🚀

**Learn coding in a fun and easy way!**

This project is a kid-friendly website designed to teach coding to children ages 4 to 16 using Scratch, Python, JavaScript, and C++.

## 📚 What Kids Will Learn
- **Ages 4–6:** Scratch 3.0 Playground (drag-and-drop coding)
- **Ages 7–10:** Python Explorers (basic programming)
- **Ages 11–13:** JavaScript Creators (interactive websites)
- **Ages 14–16:** C++ Masters (real programming concepts)

## 🌟 Features
- Fun projects like games, animations, and apps
- Colorful, mobile-friendly design
- Progressive Web App (PWA) — installable like a real app
- Easy for beginners

## 🚀 How to Use
1. Open the website in Google Chrome
2. Choose your age group
3. Start learning and creating!
4. (Optional) Install the app on your device for offline use

## 🔗 Live Website
(Your live link will appear here after deployment)

---

**Made with ❤️ for future coders!**
